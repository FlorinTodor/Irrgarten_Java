package irrgarten;
import java.awt.RenderingHints;
import javax.swing.text.AbstractDocument;

/**
 *
 * @author flo
 */

  public enum Directions{LEFT,RIGHT,UP,DOWN};
